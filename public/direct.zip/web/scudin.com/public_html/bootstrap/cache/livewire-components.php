<?php return array (
  'product-ratings' => 'App\\Http\\Livewire\\ProductRatings',
  'search-user' => 'App\\Http\\Livewire\\SearchUser',
);