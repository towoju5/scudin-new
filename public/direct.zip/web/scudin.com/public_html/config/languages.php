<?php

return [
  'en' => 'English',
  'es' => 'Spanish',
  'fr' => 'French',
  'de' => 'German',
];