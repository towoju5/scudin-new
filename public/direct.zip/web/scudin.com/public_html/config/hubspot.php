<?php

return [
	'api_key' => env('HUBSPOT_API_KEY'),

	'client_options' => [
		'http_errors' => true,
	],
];
